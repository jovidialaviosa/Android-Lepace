package com.example.leplaceapplication;

public class SelectRoleRegister {

}

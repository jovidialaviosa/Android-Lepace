package com.example.leplaceapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.leplaceapplication.MainActivity;
import com.example.leplaceapplication.R;

public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private Button regButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        emailEditText = findViewById(R.id.textfield_email);
        passwordEditText = findViewById(R.id.textfield_pass);
        loginButton = findViewById(R.id.button_login);
        regButton = findViewById(R.id.create_acc);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Perform validation, e.g., check if email and password are not empty
                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform login logic here, e.g., validate credentials against a database

                    // For demonstration purposes, let's assume the login is successful
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                    // Start the MainActivity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);

                    // Close the LoginActivity
                    finish();
                }
            }
        });
        Button regButton  = findViewById(R.id.create_acc);

        regButton .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kode untuk perpindahan halaman di sini

                // Contoh: Pindah ke Activity lain
                Intent intent = new Intent(LoginActivity.this, SelectRoleRegister.class);
                startActivity(intent);

                // Jika Anda ingin menutup Activity saat ini setelah perpindahan halaman
                finish();
            }
        });



    }
}

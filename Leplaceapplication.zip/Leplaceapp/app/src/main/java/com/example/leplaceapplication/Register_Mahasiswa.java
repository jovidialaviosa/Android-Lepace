package com.example.leplaceapplication;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register_Mahasiswa extends AppCompatActivity {
    private Spinner roleSpinner;
    private EditText nameEditText, nimEditText, emailEditText, passwordEditText;
    private Button registerButton;

    private String selectedRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_mhs);

        //roleSpinner = findViewById(R.id.roleSpinner);
        nameEditText = findViewById(R.id.nama_mhs);
        nimEditText = findViewById(R.id.nim_mhs);
        emailEditText = findViewById(R.id.email_mhs);
        passwordEditText = findViewById(R.id.pass_mhs);
        registerButton = findViewById(R.id.regist_btnn);

        // Set up the spinner adapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.pilihan_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roleSpinner.setAdapter(adapter);

        // Handle spinner item selection
        roleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedRole = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Handle register button click
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String nip = nimEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Perform validation and registration logic here
                if (name.isEmpty() || nip.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Register_Mahasiswa.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform registration logic
                    // Call your API or perform database operations here
                    // You can access the selected role with the "selectedRole" variable
                    // Display success or failure message accordingly
                    Toast.makeText(Register_Mahasiswa.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

}

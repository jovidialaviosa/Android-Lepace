package com.example.leplaceapplication;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.AdapterView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SelectRoleRegister extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.role);

        Spinner spinner = findViewById(R.id.spinner);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedRole = parent.getItemAtPosition(position).toString();

                if (selectedRole.equals("Dosen")) {
                    // Pindah ke halaman register_dosen
                    Intent intent = new Intent(SelectRoleRegister.this, Register_Dosen.class);
                    startActivity(intent);
                } else if (selectedRole.equals("Mahasiswa")) {
                    // Pindah ke halaman register_mahasiswa
                    Intent intent = new Intent(SelectRoleRegister.this, Register_Mahasiswa.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Tidak ada tindakan khusus yang diambil jika tidak ada yang dipilih
            }
        });
    }
}

